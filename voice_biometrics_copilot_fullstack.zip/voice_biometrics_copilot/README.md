# Voice Biometrics Authentication System — Full Stack

Advanced starter implementing speaker enrollment, verification, MFCC/delta features,
GMM diagnostics, cosine similarity, baseline diarization, risk scoring, audit history,
Advanced Analytics, and an AI Copilot.

## Run
Backend:
    cd backend
    python -m venv .venv
    # activate the venv
    pip install -r requirements.txt
    uvicorn app.main:app --reload --port 8000

Frontend:
    cd frontend
    npm install
    npm run dev

Open http://localhost:5173.

Optional AI Copilot:
    AI_API_KEY=...
    AI_BASE_URL=https://your-openai-compatible-provider/v1
    AI_MODEL=...

Without these variables, Copilot uses a local fallback.

Production: use TLS, encrypt biometric templates, add liveness/anti-spoofing,
calibrate FAR/FRR thresholds, apply rate limits, retention/deletion controls,
and use a dedicated production speaker-embedding model such as ECAPA-TDNN.
