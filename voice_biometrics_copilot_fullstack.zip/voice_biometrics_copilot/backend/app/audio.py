import io
import numpy as np, librosa
from sklearn.preprocessing import normalize
from sklearn.mixture import GaussianMixture
from sklearn.cluster import KMeans
SR=16000
def load_audio(data):
    y,sr=librosa.load(io.BytesIO(data),sr=SR,mono=True)
    y,_=librosa.effects.trim(y,top_db=28)
    if len(y)<SR: raise ValueError("Audio is too short; provide at least 1 second.")
    return librosa.util.normalize(y),sr
def mfcc_features(y,sr=SR):
    m=librosa.feature.mfcc(y=y,sr=sr,n_mfcc=20,n_fft=512,hop_length=160,win_length=400)
    return np.vstack([m,librosa.feature.delta(m),librosa.feature.delta(m,order=2)]).T.astype("float32")
def embedding(y,sr=SR):
    f=mfcc_features(y,sr)
    e=np.concatenate([f.mean(0),f.std(0)+1e-6])
    return normalize(e.reshape(1,-1))[0]
def cosine(a,b):
    return float(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)+1e-9))
def gmm_summary(y,sr=SR):
    f=mfcc_features(y,sr); k=min(8,max(1,len(f)//20))
    g=GaussianMixture(n_components=k,covariance_type="diag",random_state=7).fit(f)
    return {"components":k,"lower_bound":float(g.lower_bound_),"bic":float(g.bic(f)),"aic":float(g.aic(f))}
def vad(y,sr=SR):
    rms=librosa.feature.rms(y=y,frame_length=400,hop_length=160)[0]
    active=rms>max(float(np.percentile(rms,35)),float(rms.mean()*.55)); out=[]; start=None
    for i,on in enumerate(active):
        if on and start is None:start=i
        if (not on or i==len(active)-1) and start is not None:
            end=i if not on else i+1; a=start*160/sr; b=end*160/sr
            if b-a>=.2: out.append({"start":round(a,3),"end":round(b,3)})
            start=None
    return out
def diarize(y,sr=SR):
    segs=vad(y,sr)
    if len(segs)<2:return [{"speaker":"SPEAKER_00",**s} for s in segs]
    xs=[]; valid=[]
    for s in segs:
        part=y[int(s["start"]*sr):int(s["end"]*sr)]
        if len(part)>=int(.25*sr):xs.append(embedding(part,sr));valid.append(s)
    if len(xs)<2:return [{"speaker":"SPEAKER_00",**s} for s in valid]
    labels=KMeans(n_clusters=2,random_state=7,n_init=10).fit_predict(np.vstack(xs))
    return [{"speaker":f"SPEAKER_{int(l):02d}",**s} for s,l in zip(valid,labels)]
