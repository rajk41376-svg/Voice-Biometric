from sqlalchemy import create_engine,String,Float,Integer,Text,DateTime
from sqlalchemy.orm import DeclarativeBase,Mapped,mapped_column,sessionmaker
from datetime import datetime
from .config import settings
engine=create_engine(settings.database_url,connect_args={"check_same_thread":False} if settings.database_url.startswith("sqlite") else {})
SessionLocal=sessionmaker(bind=engine)
class Base(DeclarativeBase): pass
class Speaker(Base):
    __tablename__="speakers"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(120),unique=True,index=True)
    template:Mapped[str]=mapped_column(Text)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
class Verification(Base):
    __tablename__="verifications"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    speaker_id:Mapped[int|None]=mapped_column(Integer,nullable=True)
    score:Mapped[float]=mapped_column(Float)
    threshold:Mapped[float]=mapped_column(Float)
    accepted:Mapped[int]=mapped_column(Integer)
    risk:Mapped[float]=mapped_column(Float)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
Base.metadata.create_all(engine)
def get_db():
    db=SessionLocal()
    try: yield db
    finally: db.close()
