import httpx
from .config import settings
SYSTEM="""You are an AI Copilot for a voice biometrics security console.
Be concise. Never claim a biometric match is certain. Treat similarity as evidence,
recommend liveness/anti-spoofing, threshold calibration, audit review and privacy controls."""
async def ask(question,context):
    if settings.ai_api_key and settings.ai_base_url and settings.ai_model:
        payload={"model":settings.ai_model,"messages":[{"role":"system","content":SYSTEM},{"role":"user","content":f"Context: {context}\nQuestion: {question}"}],"temperature":0.2}
        async with httpx.AsyncClient(timeout=45) as c:
            r=await c.post(settings.ai_base_url+"/chat/completions",json=payload,headers={"Authorization":f"Bearer {settings.ai_api_key}"})
            r.raise_for_status()
            return {"answer":r.json()["choices"][0]["message"]["content"],"actions":["Review audit trail","Validate threshold calibration"]}
    q=question.lower()
    if "threshold" in q:
        return {"answer":"Choose the verification threshold from a representative validation set using FAR/FRR or DET/ROC analysis; do not tune it from one recording.","actions":["Run validation set","Measure FAR/FRR","Recalibrate threshold"]}
    if "risk" in q or "failed" in q:
        return {"answer":"A failed match is a risk signal, not proof of fraud. Check audio quality, replay/liveness signals and attempt velocity.","actions":["Inspect attempts","Check liveness","Apply rate limiting"]}
    if "diar" in q:
        return {"answer":"Diarization segments multi-speaker audio before verification. The bundled baseline is lightweight; production systems should use a dedicated diarization model and measure DER.","actions":["Inspect segments","Measure DER","Upgrade diarization model"]}
    return {"answer":"I can explain verification scores, investigate failed attempts, plan threshold calibration, review diarization, and suggest security actions.","actions":["Run verification","Open Advanced Analytics","Review audit history"]}
