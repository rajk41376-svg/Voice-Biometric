import json
from fastapi import FastAPI,UploadFile,File,Depends,HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import desc
from .db import get_db,Speaker,Verification
from .audio import load_audio,embedding,cosine,gmm_summary,diarize
from .config import settings
from .copilot import ask
app=FastAPI(title="Voice Biometrics Authentication API",version="2.0")
app.add_middleware(CORSMiddleware,allow_origins=["http://localhost:5173","http://127.0.0.1:5173"],allow_methods=["*"],allow_headers=["*"])
@app.get("/health")
def health(): return {"status":"ok"}
@app.get("/api/dashboard")
def dashboard(db:Session=Depends(get_db)):
    rows=db.query(Verification).all(); accepted=sum(x.accepted for x in rows)
    return {"speakers":db.query(Speaker).count(),"total_verifications":len(rows),"accepted":accepted,"rejected":len(rows)-accepted,"acceptance_rate":round(accepted/len(rows)*100,2) if rows else 0,"average_score":round(sum(x.score for x in rows)/len(rows),4) if rows else 0}
@app.get("/api/speakers")
def speakers(db:Session=Depends(get_db)):
    return [{"id":s.id,"name":s.name,"created_at":s.created_at.isoformat()} for s in db.query(Speaker).order_by(desc(Speaker.created_at)).all()]
@app.post("/api/enroll/{name}")
async def enroll(name:str,audio:UploadFile=File(...),db:Session=Depends(get_db)):
    try:y,sr=load_audio(await audio.read()); e=embedding(y,sr); stats=gmm_summary(y,sr)
    except Exception as ex: raise HTTPException(400,str(ex))
    s=db.query(Speaker).filter(Speaker.name==name).first()
    if not s:s=Speaker(name=name,template=json.dumps(e.tolist()));db.add(s)
    else:s.template=json.dumps(e.tolist())
    db.commit();db.refresh(s)
    return {"id":s.id,"name":s.name,"embedding_dimensions":len(e),"model_stats":stats}
@app.post("/api/verify")
async def verify(audio:UploadFile=File(...),db:Session=Depends(get_db)):
    try:y,sr=load_audio(await audio.read());e=embedding(y,sr)
    except Exception as ex:raise HTTPException(400,str(ex))
    cs=db.query(Speaker).all()
    if not cs:raise HTTPException(404,"No enrolled speakers.")
    score,s=max((cosine(e,json.loads(x.template)),x) for x in cs)
    t=settings.verification_threshold; ok=score>=t; risk=max(0,min(1,(t-score+.15)/.30))
    db.add(Verification(speaker_id=s.id,score=score,threshold=t,accepted=int(ok),risk=risk));db.commit()
    return {"speaker_id":s.id if ok else None,"speaker":s.name if ok else None,"score":round(score,4),"threshold":t,"accepted":ok,"risk":round(risk,4),"explanation":"Strong similarity above threshold." if ok else "Similarity is below threshold."}
@app.post("/api/advanced/analyze")
async def analyze(audio:UploadFile=File(...)):
    try:
        y,sr=load_audio(await audio.read())
        return {"duration_seconds":round(len(y)/sr,3),"sample_rate":sr,"gmm_ubm":gmm_summary(y,sr),"diarization":diarize(y,sr),"features":{"mfcc":20,"delta":20,"delta2":20,"embedding_dimensions":120},"security":{"liveness":"not_enabled","replay_detection":"not_enabled"}}
    except Exception as ex:raise HTTPException(400,str(ex))
@app.get("/api/audit")
def audit(db:Session=Depends(get_db)):
    return [{"id":r.id,"score":round(r.score,4),"threshold":r.threshold,"accepted":bool(r.accepted),"risk":round(r.risk,4),"created_at":r.created_at.isoformat()} for r in db.query(Verification).order_by(desc(Verification.created_at)).limit(100).all()]
@app.post("/api/copilot")
async def copilot(payload:dict):
    return await ask(payload.get("question",""),payload.get("context",{}))
