import os
class Settings:
    database_url=os.getenv("DATABASE_URL","sqlite:///./voice.db")
    verification_threshold=float(os.getenv("VERIFICATION_THRESHOLD","0.78"))
    ai_api_key=os.getenv("AI_API_KEY","")
    ai_base_url=os.getenv("AI_BASE_URL","").rstrip("/")
    ai_model=os.getenv("AI_MODEL","")
settings=Settings()
